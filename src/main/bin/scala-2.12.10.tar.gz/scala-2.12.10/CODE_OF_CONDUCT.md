all repositories in these organizations:

* [scala](https://github.com/scala)
* [scalacenter](https://github.com/scalacenter)
* [lampepfl](https://github.com/lampepfl)

are covered by the Scala Code of Conduct: https://scala-lang.org/conduct/
